<footer class="footer seccion">
        <div class="contenedor contenedor-footer">

            <nav class="navegacion">
                
            </nav>

            <p class="copyright">Todos los derechos reservados <?php echo date("Y"); ?> &copy; - Luis Vazquez Perez</p>
        </div>
    </footer>


    <script src="/build/js/bundle.min.js"></script>
</body>

</html>