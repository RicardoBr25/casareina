<fieldset>
    <legend>Informacion General</legend>

    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="vendedor[nombre]" placeholder="Nombre Vendedor" value="<?php echo s($vendedor->nombre); ?>">

    <label for="apellido">Apellido:</label>
    <input type="text" id="apellido" name="vendedor[apellido]" placeholder="Apellido Vendedor" value="<?php echo s($vendedor->apellido); ?>">

</fieldset>

<fieldset>
    <legend>Informacion extra</legend>
    <label for="telefono">Telefono:</label>
    <input type="text" id="telefono" name="vendedor[telefono]"
     placeholder="Telefono Vendedor" value="<?php echo s($vendedor->telefono); ?>">

     <label for="email">E-mail:</label>
    <input type="email" id="email" name="vendedor[email]"
     placeholder="email Vendedor" value="<?php echo s($vendedor->email); ?>">

     <label for="password">Password:</label>
    <input type="text" id="password" name="vendedor[password]"
     placeholder="password" value="<?php echo s($vendedor->password); ?>">


     
</fieldset>