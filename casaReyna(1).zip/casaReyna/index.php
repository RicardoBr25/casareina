<?php 
    require 'includes/app.php';
    incluirTemplate('header', $inicio = true);
?>
<h1>CASA REINA</h1>
<?php 
    incluirTemplate('footer');
?>