<form method="POST" class="formulario">
            <fieldset>
               <legend>Email y Password</legend> 
              
               <label for="email">Nombre</label>
               <input type="text" name="nombre" placeholder="Nombre del vendedor" id="vendedor" >

               <label for="password">Apellido Paterno</label>
               <input type="text" name="apellido" placeholder="Apellido Paterno del vendedor" id="apellido" >

               label for="password">Apellido Materno</label>
               <input type="text" name="apellidoM" placeholder="Apellido Materno del vendedor" id="apellidoM" >
       
            </fieldset>

            <input type="submit" value="Dar de alta al vendedor" class="boton boton-verde">

        </form>