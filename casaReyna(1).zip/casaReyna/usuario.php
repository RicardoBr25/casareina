<?php

//Importar la conexión
require 'includes/app.php';
$db = conectarDB();

//Crear un email y password 
$email = "vendedor@correo.com";
$password = "986432";

$passwordHash = password_hash($password, PASSWORD_BCRYPT);

//Query para crear el ususario 
$query = " INSERT INTO usuarios (email, password) VALUES 
( '${email}','${passwordHash}')";

//echo $query;

//exit;

//Agregarlo a la base de datos
mysqli_query($db, $query); 