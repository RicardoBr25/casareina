<?php

namespace App;
class Usuario extends ActiveRecord{
    
    protected static $tabla = ' usuarios';
    protected static $columnasDB = [
        'id', 'email', 'password']; 

    public $id;
    public $email;
    public $password;
 

    public function __construct($args = [])
    {
        $this->id = $args['id'] ?? null;
        $this->email = $args['email'] ?? '';
        $this->password = $args['password'] ?? '';
        
       
    }

    public function validar()
    {

        if (!$this->email) {
            self::$errores[] = "Debes añadir un email";
        }

        if (!$this->password) {
            self::$errores[] = "El password es obligatorio";
        }

       
        return self::$errores;
    }


}
